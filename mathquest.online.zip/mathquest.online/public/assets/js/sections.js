function openModal(id){ document.getElementById(id).style.display = 'flex'; }
function closeModal(id){ document.getElementById(id).style.display = 'none'; }

function openEditSectionModal(id, name, year){
    document.getElementById('editSectionForm').action = `/teacher/sections/${id}/update`;
    document.getElementById('editSectionName').value = name;
    document.getElementById('editSectionYear').value = year;
    openModal('editSectionModal');
}

function confirmArchiveSection(id, name){
    document.getElementById('archiveSectionForm').action = `/teacher/sections/${id}/archive`;
    document.querySelector('#archiveSectionModal .modal-title').textContent = `Archive Section "${name}"`;
    openModal('archiveSectionModal');
}

function openAddStudentModal(sectionId = ''){
    document.getElementById('addStudentSectionId').value = sectionId;
    openModal('addStudentModal');
}

function openEditStudentModal(id, first, middle, last, lrn, section_id, category){
    document.getElementById('editStudentId').value = id;
    document.getElementById('editFirstName').value = first;
    document.getElementById('editMiddleName').value = middle;
    document.getElementById('editLastName').value = last;
    document.getElementById('editLRN').value = lrn;
    document.getElementById('editSectionId').value = section_id;
    document.getElementById('editLearnerCategory').value = category;
    openModal('editStudentModal');
}

function confirmArchiveStudent(studentId, studentName){
    if (!confirm('Archive student: ' + studentName + ' ?')) return;
    const f = document.createElement('form');
    f.method = 'POST'; f.style.display='none';
    const inp = document.createElement('input'); inp.name='student_id'; inp.value=studentId; f.appendChild(inp);
    const btn = document.createElement('input'); btn.type='hidden'; btn.name='delete_student'; btn.value='1'; f.appendChild(btn);
    document.body.appendChild(f); f.submit();
}

function confirmArchiveStudentList(sectionId, sectionName){
    if (!confirm(`Archive student list for ${sectionName || 'this section'}?`)) return;
    const f = document.createElement('form'); f.method='POST'; f.style.display='none';
    const inp = document.createElement('input'); inp.name='section_id'; inp.value=sectionId; f.appendChild(inp);
    const btn = document.createElement('input'); btn.type='hidden'; btn.name='delete_student_list'; btn.value='1'; f.appendChild(btn);
    document.body.appendChild(f); f.submit();
}

function filterSections() {
    const input = document.getElementById('searchSections').value.toLowerCase();
    const rows = document.querySelectorAll('#sectionsTableBody tr');
    rows.forEach(row => {
        const sectionNameCell = row.cells[1];
        row.style.display = sectionNameCell && sectionNameCell.textContent.toLowerCase().includes(input) ? '' : 'none';
    });
}

function filterByCategory(val){
    const rows = document.querySelectorAll('#studentsTableBody tr');
    rows.forEach(r => r.style.display = !val || r.dataset.category === val ? '' : 'none');
}

function searchStudents(){
    const q = document.getElementById('searchInput')?.value.toLowerCase() || '';
    const rows = document.querySelectorAll('#studentsTableBody tr');
    rows.forEach(r => r.style.display = r.innerText.toLowerCase().includes(q) ? '' : 'none');
}

function confirmResetPasscode(studentId){
    if(confirm("Reset this student's passcode?")) window.location.href = `reset_passcode.php?student_id=${studentId}`;
}

function viewStudentProfile(studentId){
    window.location.href = `student_profile.php?student_id=${studentId}`;
}
