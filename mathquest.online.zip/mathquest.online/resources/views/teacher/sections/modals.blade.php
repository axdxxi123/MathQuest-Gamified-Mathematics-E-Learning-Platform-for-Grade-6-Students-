<div class="modal-overlay" id="createSectionModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title">Create Section</h2>
            <p>Add a new class section</p>
        </div>
        <form method="POST" action="{{ route('teacher.sections.store') }}">
            @csrf
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Section Name *</label>
                    <input class="form-input" name="section_name" required>
                </div>
                <div class="form-group">
                    <label class="form-label">School Year *</label>
                    <input class="form-input" name="school_year" placeholder="2024-2025" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('createSectionModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Create Section</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="editSectionModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title">Edit Section</h2>
            <p>Update section details</p>
        </div>
        <form method="POST" action="" id="editSectionForm">
            @csrf
            @method('POST')
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Section Name *</label>
                    <input class="form-input" name="section_name" id="editSectionName" required>
                </div>
                <div class="form-group">
                    <label class="form-label">School Year *</label>
                    <input class="form-input" name="school_year" id="editSectionYear" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('editSectionModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Update Section</button>
            </div>
        </form>
    </div>
</div>

<div class="modal-overlay" id="archiveSectionModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title">Archive Section</h2>
            <p>Archiving a section will also archive all students. This cannot be undone.</p>
        </div>
        <form method="POST" action="" id="archiveSectionForm">
            @csrf
            @method('DELETE')
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('archiveSectionModal')">Cancel</button>
                <button type="submit" class="btn btn-danger">Archive</button>
            </div>
        </form>
    </div>
</div>

{{-- Add Student --}}
<div class="modal-overlay" id="addStudentModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 class="modal-title">Add Student</h2>
            <p>Create a new student account</p>
        </div>
        <form method="POST" action="{{ route('teacher.students.store') }}">
            @csrf
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">First Name *</label>
                    <input class="form-input" name="first_name" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Middle Name</label>
                    <input class="form-input" name="middle_name">
                </div>
                <div class="form-group">
                    <label class="form-label">Last Name *</label>
                    <input class="form-input" name="last_name" required>
                </div>
                <div class="form-group">
                    <label class="form-label">LRN *</label>
                    <input class="form-input" name="lrn" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Section *</label>
                    <select class="form-input" name="section_id" required>
                        @foreach($sections as $section)
                            <option value="{{ $section->section_id }}" {{ isset($section_id) && $section_id == $section->section_id ? 'selected' : '' }}>
                                {{ $section->section_name }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Learner Category *</label>
                    <select class="form-input" name="learner_category" required>
                        <option value="Average Learner" selected>Average Learner</option>
                        <option value="Slow Learner">Slow Learner</option>
                        <option value="Fast Learner">Fast Learner</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal('addStudentModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Add Student</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditSectionModal(sectionId, sectionName, schoolYear) {
    document.getElementById('editSectionName').value = sectionName;
    document.getElementById('editSectionYear').value = schoolYear;

    const form = document.getElementById('editSectionForm');
    form.action = `/teacher/sections/${sectionId}/update`; // update route
    form.querySelector('input[name="_method"]').value = 'POST'; // use POST for update

    openModal('editSectionModal');
}

function confirmArchiveSection(sectionId) {
    const form = document.getElementById('archiveSectionForm');
    form.action = `/teacher/sections/${sectionId}/archive`;
    openModal('archiveSectionModal');
}
</script>
