@extends('teacher.layouts.app_sections')

@section('title', 'Sections & Students')

@section('content')
<div class="top-header">
    <div>
        <h1 class="page-title">Sections & Students</h1>
        <p class="page-subtitle">Manage class sections and student accounts</p>
    </div>
</div>

<div class="content-area">
    {{-- Alerts --}}
    @if(session('success'))
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> {{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> {{ session('error') }}</div>
    @endif

    {{-- Stats --}}
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-value">{{ $sections->count() }}</div>
                    <div class="stat-label">Total Sections</div>
                </div>
                <div class="stat-icon"><i class="fas fa-users"></i></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-value">{{ $students->count() }}</div>
                    <div class="stat-label">Total Students</div>
                </div>
                <div class="stat-icon"><i class="fas fa-user-graduate"></i></div>
            </div>
        </div>
        <div class="stat-card">
            <div class="stat-header">
                <div>
                    <div class="stat-value">{{ $class_average_score }}%</div>
                    <div class="stat-label">Avg. Score</div>
                </div>
                <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
            </div>
        </div>
    </div>

    {{-- Quick Actions --}}
    <div class="quick-actions">
        <button class="action-btn" onclick="openModal('createSectionModal')">
            <div class="action-icon"><i class="fas fa-plus"></i></div>
            <div class="action-text">Create Section</div>
            <div class="action-desc">Add new class section</div>
        </button>

        <button class="action-btn" onclick="openModal('addStudentModal')">
            <div class="action-icon"><i class="fas fa-user-plus"></i></div>
            <div class="action-text">Add Student</div>
            <div class="action-desc">Create student account</div>
        </button>

        <a href="{{ route('teacher.student_archives.index') }}" class="action-btn">
            <div class="action-icon"><i class="fas fa-archive"></i></div>
            <div class="action-text">View Archives</div>
            <div class="action-desc">View archived classes and students</div>
        </a>
    </div>

    {{-- Sections Tab --}}
    <div id="sectionsTab" class="tab-content" style="{{ !$section_id ? 'display:block;' : 'display:none;' }}">
        <div class="data-table">
            <div class="table-header">
                <h2 class="table-title">Class Sections</h2>
                <div class="table-actions" style="display:flex; gap:5px; align-items:center;">
                    <button class="btn btn-primary" onclick="openModal('createSectionModal')">
                        <i class="fas fa-plus"></i> Create Section
                    </button>
                    <input type="text" class="table-search" placeholder="Search sections..." id="searchSections" onkeyup="filterSections()">
                </div>
            </div>

            <div class="table-content">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Section Name</th>
                            <th>Student Count</th>
                            <th>School Year</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($sections as $index => $section)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td><strong>{{ $section->section_name }}</strong></td>
                                <td>{{ $section->students->where('archived',0)->count() }} students</td>
                                <td>{{ $section->school_year }}</td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="{{ route('teacher.sections.index', ['section_id' => $section->section_id]) }}" class="btn btn-secondary" title="View Students">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <button class="btn btn-primary" title="Edit Section" onclick="openEditSectionModal('{{ $section->section_id }}', '{{ $section->section_name }}', '{{ $section->school_year }}')">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <button class="btn btn-danger" title="Archive Section" onclick="confirmArchiveSection('{{ $section->section_id }}', '{{ $section->section_name }}')">
                                            <i class="fas fa-archive"></i> Archive
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center">No Sections Yet. Create a class section to get started.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- Students Tab --}}
    <div id="studentsTab" class="tab-content" style="{{ $section_id ? 'display:block;' : 'display:none;' }}">
        <div class="filters">
            <div class="filter-group">
                <label>Filter by Category:</label>
                <select class="select-input" onchange="filterByCategory(this.value)">
                    <option value="">All Categories</option>
                    @foreach($learner_categories as $category)
                        <option value="{{ $category }}">{{ $category }}</option>
                    @endforeach
                </select>
            </div>
            <div class="filter-group">
                <label>Search:</label>
                <input type="text" class="form-input" placeholder="Search students..." onkeyup="searchStudents()">
            </div>
            <a href="{{ route('teacher.sections.index') }}" class="btn btn-primary btn-small">
                <i class="fas fa-arrow-left"></i> Back to Sections
            </a>
        </div>

        <div class="data-table">
            <div class="table-header">
                <h2 class="table-title">Student List</h2>
                <div class="table-actions">
                    <button class="btn btn-primary" onclick="openModal('addStudentModal')"><i class="fas fa-user-plus"></i> Add Student</button>
                </div>
            </div>
            <div class="table-content">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Name</th>
                            <th>LRN</th>
                            <th>Section</th>
                            <th>Category</th>
                            <th>Passcode</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($students as $index => $student)
                            <tr data-section="{{ $student->section_id }}" data-category="{{ $student->learner_category }}">
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $student->first_name }} {{ $student->last_name }}</td>
                                <td>{{ $student->lrn }}</td>
                                <td>{{ $student->section->section_name ?? 'Unassigned' }}</td>
                                <td><span class="status-badge {{ strtolower(str_replace(' ', '-', $student->learner_category)) }}">{{ $student->learner_category }}</span></td>
                                <td>{{ $student->passcode }}</td>
                                <td>
                                    <div class="action-buttons-2">
                                        <button class="btn-icon view" onclick="viewStudentProfile('{{ $student->student_id }}')"><i class="fas fa-eye"></i></button>
                                        <button class="btn-icon edit" onclick="openEditStudentModal('{{ $student->student_id }}', '{{ $student->first_name }}', '{{ $student->middle_name }}', '{{ $student->last_name }}', '{{ $student->lrn }}', '{{ $student->section_id }}', '{{ $student->learner_category }}')"><i class="fas fa-edit"></i></button>
                                        <button class="btn-icon delete" onclick="confirmArchiveStudent('{{ $student->student_id }}', '{{ $student->first_name }} {{ $student->last_name }}')"><i class="fas fa-archive"></i></button>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center">No Students Yet. Add a student to get started.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- Modals --}}
    @include('teacher.sections.modals')

</div>
@endsection
