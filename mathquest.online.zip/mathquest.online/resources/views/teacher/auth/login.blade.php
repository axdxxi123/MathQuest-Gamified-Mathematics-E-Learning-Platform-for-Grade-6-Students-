@extends('layouts.guest')

@section('title', 'Teacher Login | MathQuest')

@section('content')
<link rel="stylesheet" href="{{ asset('assets/css/login.css') }}">

<div class="top-logo-container">
    <a href="{{ route('index') }}" class="logo-link">
        <div class="logo-icon"><i class="fas fa-gamepad"></i></div>
        <div class="logo-text">MATHQUEST</div>
    </a>
</div>

<div class="modal-container">
    <div id="login-form">
        <div class="modal-header">
            <h2>Welcome!</h2>
            <p>Sign in to MathQuest Teacher Portal</p>
        </div>

        <div class="modal-body">
            @if(session('error'))
                <div class="alert alert-error">{{ session('error') }}</div>
            @endif

            @if(session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <form method="POST" action="{{ route('teacher.login') }}">
                @csrf
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-input" placeholder="Enter your email" value="{{ old('email') }}" required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-input" placeholder="Enter your password" required>
                </div>

                <div class="checkbox-group">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Remember me
                    </label>
                </div>

                <button type="submit" class="submit-btn"><i class="fas fa-sign-in-alt"></i> Sign In</button>

                <div class="register-link">
                    Don't have an account? <a href="{{ route('teacher.signup') }}">Sign Up</a>
                </div>

                <div class="back-btn-container">
                    <a href="{{ route('index') }}" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Home</a>
                </div>

                <div class="form-footer">
                    <p>MathQuest © 2025 | Mapaniqui Elementary School</p>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
