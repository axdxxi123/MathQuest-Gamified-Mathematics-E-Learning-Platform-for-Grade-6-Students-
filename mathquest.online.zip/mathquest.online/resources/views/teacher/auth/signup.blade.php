@extends('layouts.guest')

@section('title', 'Teacher Sign Up | MathQuest')

@section('content')
<link rel="stylesheet" href="{{ asset('assets/css/signup.css') }}">

<div class="top-logo-container">
    <a href="{{ route('index') }}" class="logo-link">
        <div class="logo-icon"><i class="fas fa-gamepad"></i></div>
        <div class="logo-text">MATHQUEST</div>
    </a>
</div>

<div class="modal-container">
    <div id="register-form">
        <div class="modal-header">
            <h2>Start Your Quest!</h2>
            <p>Create your MathQuest teacher account</p>
        </div>

        <div class="modal-body">
            @if ($errors->any())
                <div class="alert alert-error">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('teacher.signup') }}">
                @csrf
                <div class="form-group">
                    <label>First Name</label>
                    <input type="text" name="firstname" class="form-input" value="{{ old('firstname') }}" required>
                </div>

                <div class="form-group">
                    <label>Middle Name</label>
                    <input type="text" name="middlename" class="form-input" value="{{ old('middlename') }}">
                </div>

                <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" name="lastname" class="form-input" value="{{ old('lastname') }}" required>
                </div>

                <div class="form-group">
                    <label>Position</label>
                    <select name="position" class="form-input" required>
                        <option value="">Select Position</option>
                        <option value="Teacher I" {{ old('position')=='Teacher I'?'selected':'' }}>Teacher I</option>
                        <option value="Teacher II" {{ old('position')=='Teacher II'?'selected':'' }}>Teacher II</option>
                        <option value="Teacher III" {{ old('position')=='Teacher III'?'selected':'' }}>Teacher III</option>
                        <option value="Teacher IV" {{ old('position')=='Teacher IV'?'selected':'' }}>Teacher IV</option>
                        <option value="Teacher V" {{ old('position')=='Teacher V'?'selected':'' }}>Teacher V</option>
                        <option value="Teacher VI" {{ old('position')=='Teacher VI'?'selected':'' }}>Teacher VI</option>
                        <option value="Master Teacher I" {{ old('position')=='Master Teacher I'?'selected':'' }}>Master Teacher I</option>
                        <option value="Master Teacher II" {{ old('position')=='Master Teacher II'?'selected':'' }}>Master Teacher II</option>
                        <option value="Master Teacher III" {{ old('position')=='Master Teacher III'?'selected':'' }}>Master Teacher III</option>
                        <option value="Master Teacher IV" {{ old('position')=='Master Teacher IV'?'selected':'' }}>Master Teacher IV</option>
                        <option value="Master Teacher V" {{ old('position')=='Master Teacher V'?'selected':'' }}>Master Teacher V</option>
                        <option value="Master Teacher VI" {{ old('position')=='Master Teacher VI'?'selected':'' }}>Master Teacher VI</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" name="email" class="form-input" value="{{ old('email') }}" required>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-input" required>
                </div>

                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="password_confirmation" class="form-input" required>
                </div>

                <div class="form-group">
                    <label>
                        <input type="checkbox" name="terms" {{ old('terms') ? 'checked' : '' }} required> I agree to the Terms and Conditions
                    </label>
                </div>

                <button type="submit" class="submit-btn"><i class="fas fa-user-plus"></i> Create Account</button>
            </form>

            <div class="login-link">
                Already have an account? <a href="{{ route('teacher.login') }}">Sign In</a>
            </div>

            <div class="back-btn-container">
                <a href="{{ route('index') }}" class="back-btn"><i class="fas fa-arrow-left"></i> Back to Home</a>
            </div>
        </div>
    </div>
</div>
@endsection
