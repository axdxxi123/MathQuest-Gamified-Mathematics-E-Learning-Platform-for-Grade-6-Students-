<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Orbitron:wght@400;500;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/sections.css') }}">
</head>

<body>
    <div class="container">
        <aside class="sidebar">
            <div class="logo" id="sidebarToggle">
                <i class="fas fa-gamepad logo-icon"></i>
                <div class="logo-text">MATHQUEST</div>
            </div>
            <nav class="nav-menu">
                <a href="{{ route('teacher.dashboard.index') }}" class="nav-item">
                    <i class="fas fa-home nav-icon"></i><span>Dashboard</span>
                </a>
                <a href="{{ route('teacher.sections.index') }}" class="nav-item active">
                    <i class="fas fa-users nav-icon"></i><span>Sections & Students</span>
                </a>
                <a href="{{ route('teacher.modules.index') }}" class="nav-item">
                    <i class="fas fa-book-open nav-icon"></i><span>Learning Materials</span>
                </a>
                <a href="{{ route('teacher.quizzes.index') }}" class="nav-item">
                    <i class="fas fa-clipboard-list nav-icon"></i><span>Quizzes</span>
                </a>
                <a href="{{ route('teacher.reports.index') }}" class="nav-item">
                    <i class="fas fa-chart-line nav-icon"></i><span>Reports & Analytics</span>
                </a>
                <a href="{{ route('teacher.settings.index') }}" class="nav-item">
                    <i class="fas fa-cog nav-icon"></i><span>Settings</span>
                </a>
                <a href="{{ route('teacher.logout') }}"
   class="nav-item"
   id="logout-btn">
    <i class="fas fa-sign-out-alt nav-icon"></i>
    <span>Logout</span>
</a>

            </nav>
            <div class="user-profile">
                <a href="{{ route('teacher.settings.index') }}">
                    <div class="user-avatar" id="user-avatar">
                        @if($teacher_avatar)
                        <img src="{{ asset($teacher_avatar) }}" alt="Avatar" style="width:100%; height:100%; border-radius:50%;"
                            onerror="this.style.display='none'; this.parentNode.innerHTML='{{ $sidebar_initials }}';">
                        @else
                        {{ $sidebar_initials }}
                        @endif
                    </div>
                </a>
                <div class="user-info">
                    <h4 id="user-name">{{ $teacher_name }}</h4>
                    <p id="user-type">{{ $teacher_position }}</p>
                </div>
            </div>
        </aside>
        <main class="main-content">
            @yield('content')
        </main>
    </div>
    <script src="{{ asset('assets/js/sidebar.js') }}"></script>
    <script src="{{ asset('assets/js/sections.js') }}"></script>
    <form id="teacher-logout-form"
        action="{{ route('teacher.logout') }}"
        method="POST"
        style="display: none;">
        @csrf
    </form>
</body>

</html>