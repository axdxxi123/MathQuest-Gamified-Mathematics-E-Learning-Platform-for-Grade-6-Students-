@extends('teacher.layouts.app_home')

@section('title', 'Teacher Dashboard | MathQuest')

@section('content')
<div class="welcome-banner">
    <h2 id="welcome-message">Teacher Dashboard - Manage Your Math Classes</h2>
    <p>Welcome to your MathQuest Teacher Portal. Monitor your student's<br>progress, create and upload learning materials, and manage<br>your Grade 3 Mathematics classes all in one place.</p>
</div>

<header class="top-header">
    <h1>Teacher Dashboard</h1>
</header>

<div class="stats-cards">
    <div class="stat-card sections">
        <div class="stat-icon"><i class="fas fa-users"></i></div>
        <div class="stat-info">
            <h3>{{ count($sections) }}</h3>
            <p>Total Sections</p>
        </div>
    </div>

    <div class="stat-card students">
        <div class="stat-icon"><i class="fas fa-user-graduate"></i></div>
        <div class="stat-info">
            <h3>{{ $students_count }}</h3>
            <p>Total Students</p>
        </div>
    </div>

    <div class="stat-card materials">
        <div class="stat-icon"><i class="fas fa-book"></i></div>
        <div class="stat-info">
            <h3>{{ $materials_count }}</h3>
            <p>Learning Materials</p>
        </div>
    </div>

    <div class="stat-card quizzes">
        <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
        <div class="stat-info">
            <h3>{{ $quizzes_count }}</h3>
            <p>Total Quizzes</p>
        </div>
    </div>
</div>

<div class="progress-section">
    <div class="section-header">
        <h2><i class="fas fa-history"></i>Recent Activity</h2>
    </div>
    <div class="activity-list">
        @forelse($recent_activities as $activity)
            <div class="activity-item">
                <div class="activity-icon"><i class="fas {{ $activity['icon'] }}"></i></div>
                <div class="activity-content">
                    <div class="activity-title">{{ $activity['title'] }}</div>
                    <div class="activity-desc">{{ $activity['desc'] }}</div>
                    <div class="activity-time">{{ $activity['time'] }}</div>
                </div>
            </div>
        @empty
            <div class="no-activity">No recent activity.</div><br>
        @endforelse
    </div><br>

    <div class="progress-section">
        <div class="section-header">
            <h2><i class="fas fa-chart-bar"></i>Overall Class Performance</h2>
        </div>

        <div style="margin-bottom: 20px;">
            <span><strong>Average Score:</strong> {{ $class_average_score }}%</span>
        </div>

        <div class="progress-bar">
            <div class="progress-fill" id="class-performance" style="width: {{ floatval($class_average_score) }}%"></div>
        </div>

        <p style="margin-top: 15px; font-size: 15px; color: #666;">
            <i class="fas fa-lightbulb" style="margin-right: 8px; color: var(--accent-color);"></i>
            Class average score across all sections for the current quarter. Monitor individual section performance in the Reports section.
        </p>
    </div>
</div>
@endsection
