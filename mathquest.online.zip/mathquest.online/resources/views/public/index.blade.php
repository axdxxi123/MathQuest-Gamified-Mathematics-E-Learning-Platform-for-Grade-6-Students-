@extends('layouts.public')

@section('title', 'MathQuest | Mapaniqui Elementary Grade 3')

@section('content')
<header>
    <div class="container nav-container">
        <div class="logo">
            <div class="logo-icon">
                <i class="fas fa-gamepad"></i>
            </div>
            <div class="logo-text">MathQuest</div>
        </div>

        <nav class="nav-links">
            <a href="#Home">Home</a>
            <a href="#About">About</a>
            <a href="#Contact">Contact Us</a>
        </nav>

        <a href="{{ route('teacher.login') }}" class="login-icon-btn" title="Login">
            <i class="fas fa-user"></i>
        </a>
    </div>
</header>

<section class="hero">
    <div class="hero-bg"></div>
    <div class="floating-shape shape-1"></div>
    <div class="floating-shape shape-2"></div>
    <div class="container">
        <h1><span class="floating">Math Quest</span> Teacher Portal</h1>
        <p class="hero-subtitle">A gamified learning platform designed for Grade 3 students at Mapaniqui Elementary School. Transform mathematics into an exciting adventure with interactive quizzes, levels and badge rewards!</p>
        <div class="hero-buttons">
            <a href="{{ route('teacher.login') }}" class="primary-btn pulse">
                <i class="fas fa-play-circle"></i> Log In
            </a>
            <a href="{{ route('teacher.signup') }}" class="secondary-btn">
                <i class="fas fa-user-plus"></i> Sign Up
            </a>
        </div>
        <div class="school-badge">
            <div class="badge-icon">
                <img src="{{ asset('assets/imgs/logo.png') }}" alt="School Logo">
            </div>
            <div>
                <h3 style="color: var(--dark-text);">Mapaniqui Elementary School</h3>
                <p style="color: var(--muted-text);">Designed in collaboration with<br>Grade 3 mathematics teachers</p>
            </div>
        </div>
    </div>
</section>

   <section class="features" id="About">
        <div class="container">
            <h2 class="section-title">About <span>MathQuest</span> System</h2>

            <div class="features-grid">

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-layer-group"></i>
                    </div>
                    <h3>Levels</h3>
                    <p>Students earn points from completing quizzes. Students start at Level 1 and can reach up to Level 50. This motivates students towards consistent learning and progress.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-award"></i>
                    </div>
                    <h3>Badges</h3>
                    <p>Students earn badges after achieving milestones from quiz challenges and leveling up. This encourages engagement and celebrates learning achievements.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-question-circle"></i>
                    </div>
                    <h3>Interactive Quizzes</h3>
                    <p>Teachers can create and assign quizzes for each section.

                        Quiz difficulty adapts to each student's learning speed and updates according to student performance.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-question-circle"></i>
                    </div>
                    <h3>Interactive Quizzes</h3>
                    <p>Teachers can create and assign quizzes for each section. Quiz difficulty adapts to each student's learning speed and updates according to student performance.</p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-folder-open"></i>
                    </div>
                    <h3>Learning Materials</h3>
                    <p>Teachers upload learning materials including modules, presentations, videos, images, and links. Materials assigned for the current week are highlighted for students. </p>
                </div>

                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-child"></i>
                    </div>
                    <h3>Progress Tracking</h3>
                    <p>Teachers can create sections and student lists. They can view each student's profile, level, badges, quiz history, and learner category for easy monitoring.</p>
                </div>
            </div>
        </div>
    </section>

<footer>
    <div class="container" id="Contact">
        <div class="footer-content">
            <div style="display: flex; flex-direction: column; align-items: center; text-align: center;">
                <div class="logo" style="margin-bottom: 20px;">
                    <div class="logo-icon" style="color: white;">
                        <i class="fas fa-gamepad"></i>
                    </div>
                    <div class="logo-text">MathQuest</div>
                </div>
                <p style="color: #CBD5E0;">Gamified mathematics education platform for<br>Grade 3 students of Mapaniqui Elementary School.</p>

                <div class="school-badge" style="margin-top: 30px; background: rgba(255, 255, 255, 0.1); border-color: rgba(255, 255, 255, 0.2);">
                    <div class="badge-icon" style="color: white;">
                        <i class="fas fa-medal"></i>
                    </div>
                    <div>
                        <h4 style="color: white;">Aligned with DepEd MATATAG Curriculum</h4>
                    </div>
                </div>
            </div>

            <div>
                <h3 class="footer-heading">Contact Us</h3>
                <ul class="footer-links">
                    <li><i class="fas fa-map-marker-alt"></i> Pulong Balon, Mapaniqui, Candaba, Pampanga</li>
                    <li><i class="fas fa-envelope"></i> 105940@deped.gov.ph</li>
                    <li>
                        <i class="fab fa-facebook"></i>
                        <a href="https://www.facebook.com/mapaniquies" style="color: #CBD5E0; margin-left: 5px;">
                            facebook.com/mapaniquies
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="copyright">
            <p>MathQuest © 2025 | Mapaniqui Elementary School</p>
        </div>
    </div>
</footer>
@endsection
