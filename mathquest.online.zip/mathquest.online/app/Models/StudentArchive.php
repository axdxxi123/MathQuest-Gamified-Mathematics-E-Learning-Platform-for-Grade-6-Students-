<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentArchive extends Model
{
    protected $table = 'student_archives';
    protected $primaryKey = 'archive_id';
    public $timestamps = false;
    protected $fillable = [
        'student_id','lrn','first_name','middle_name','last_name','section_id','school_year','passcode','learner_category','archived_at'
    ];
}
