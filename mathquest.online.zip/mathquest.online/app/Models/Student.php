<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Student extends Model
{
    protected $table = 'students';
    protected $primaryKey = 'student_id';
    public $timestamps = false;

    protected $fillable = [
        'section_id',
        'lrn',
        'first_name',
        'middle_name',
        'last_name',
        'passcode',
        'theta',
        'p_value',
        'current_points',
        'current_level',
        'learner_category',
        'assigned_set',
        'archived'
    ];

    protected $casts = [
        'date_created' => 'datetime',
        'archived' => 'boolean',
    ];

    public function section(): BelongsTo
    {
        return $this->belongsTo(Section::class, 'section_id', 'section_id');
    }

    public function studentQuizzes(): HasMany
    {
        return $this->hasMany(StudentQuiz::class, 'student_id', 'student_id');
    }
}
