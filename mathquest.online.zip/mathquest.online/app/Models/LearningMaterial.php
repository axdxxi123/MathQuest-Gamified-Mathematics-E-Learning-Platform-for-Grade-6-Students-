<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LearningMaterial extends Model
{
    protected $table = 'learning_materials';
    protected $primaryKey = 'material_id';
    public $timestamps = false;
    protected $casts = [
    'uploaded_at' => 'datetime',
];

    protected $fillable = [
        'teacher_id','title','quarter','week','description','type','file_path','url','uploaded_at'
    ];

    public function teacher()
    {
        return $this->belongsTo(Teacher::class, 'teacher_id');
    }
}
