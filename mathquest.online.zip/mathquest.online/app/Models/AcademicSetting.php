<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AcademicSetting extends Model
{
    protected $table = 'academic_settings';
    protected $primaryKey = 'setting_id';
    public $timestamps = false;
    protected $fillable = ['school_year','current_quarter','current_week','last_updated','updated_by'];

    public function updatedBy()
    {
        return $this->belongsTo(Teacher::class, 'updated_by');
    }
}