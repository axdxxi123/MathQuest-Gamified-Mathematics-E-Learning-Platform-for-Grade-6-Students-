<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StudentQuiz extends Model
{
    protected $table = 'student_quizzes';
    protected $primaryKey = 'student_quiz_id';
    public $timestamps = false;
    protected $casts = [
    'date_taken' => 'datetime',
];

    protected $fillable = ['student_id','quiz_id','score','date_taken'];

    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }

    public function quiz()
    {
        return $this->belongsTo(Quiz::class, 'quiz_id');
    }
}
