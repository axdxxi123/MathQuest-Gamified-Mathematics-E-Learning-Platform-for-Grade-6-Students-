<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuizAttempt extends Model
{
    protected $table = 'quiz_attempts';
    protected $primaryKey = 'attempt_id';
    public $timestamps = false;
    protected $fillable = ['student_id','quiz_id','is_completed','timestamp'];

    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }

    public function quiz()
    {
        return $this->belongsTo(Quiz::class, 'quiz_id');
    }

    public function logs()
    {
        return $this->hasMany(QuizLog::class, 'quiz_id','quiz_id');
    }
}
