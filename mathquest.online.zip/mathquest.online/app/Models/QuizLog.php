<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuizLog extends Model
{
    protected $table = 'quiz_logs';
    protected $primaryKey = 'quizlog_id';
    public $timestamps = false;
    protected $fillable = ['student_id','quiz_id','question_id','is_correct','old_theta','new_theta','timestamp'];

    public function student()
    {
        return $this->belongsTo(Student::class, 'student_id');
    }

    public function quiz()
    {
        return $this->belongsTo(Quiz::class, 'quiz_id');
    }

    public function question()
    {
        return $this->belongsTo(Question::class, 'question_id');
    }
}
