<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    protected $table = 'questions';
    protected $primaryKey = 'question_id';
    public $timestamps = false;
    protected $fillable = [
        'content','content_image','option_a','option_a_image','option_b','option_b_image','option_c','option_c_image','option_d','option_d_image','correct_option','difficulty','points','hint'
    ];

    public function quizzes()
    {
        return $this->hasMany(QuizQuestion::class, 'question_id');
    }
}
