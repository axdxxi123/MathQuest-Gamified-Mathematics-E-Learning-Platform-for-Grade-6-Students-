<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Teacher extends Authenticatable
{
    protected $table = 'teachers';
    protected $primaryKey = 'teacher_id';
    public $timestamps = false;

    protected $hidden = ['password_hash'];

    protected $fillable = [
        'first_name',
        'middle_name',
        'last_name',
        'position',
        'email',
        'password_hash',
        'profile_image',
    ];

    public function getAuthPassword()
    {
        return $this->password_hash;
    }

    public function sections(): HasMany
    {
        return $this->hasMany(Section::class, 'teacher_id', 'teacher_id');
    }

    public function learningMaterials(): HasMany
    {
        return $this->hasMany(LearningMaterial::class, 'teacher_id', 'teacher_id');
    }

    public function quizzes(): HasMany
    {
        return $this->hasMany(Quiz::class, 'teacher_id', 'teacher_id');
    }
}
