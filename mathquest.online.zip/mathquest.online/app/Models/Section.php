<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Section extends Model
{
    protected $table = 'sections';
    protected $primaryKey = 'section_id';
    public $timestamps = false;

    protected $fillable = [
        'teacher_id',
        'section_name',
        'school_year',
        'archived'
    ];

    protected $casts = [
        'archived' => 'boolean',
        'date_created' => 'datetime',
    ];

    public function teacher(): BelongsTo
    {
        return $this->belongsTo(Teacher::class, 'teacher_id', 'teacher_id');
    }

    public function students(): HasMany
    {
        return $this->hasMany(Student::class, 'section_id', 'section_id');
    }
}

