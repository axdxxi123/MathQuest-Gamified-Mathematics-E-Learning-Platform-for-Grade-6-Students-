<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QuizSection extends Model
{
    protected $table = 'quiz_sections';
    protected $primaryKey = 'quiz_section_id';
    public $timestamps = false;
    protected $fillable = ['quiz_id','section_id','assigned_date','due_date','is_active'];

    public function quiz()
    {
        return $this->belongsTo(Quiz::class, 'quiz_id');
    }

    public function section()
    {
        return $this->belongsTo(Section::class, 'section_id');
    }
}
