<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class BaseTeacherController extends Controller
{
    protected function teacherViewData(): array
    {
        $teacher = Auth::guard('teacher')->user();

        if (!$teacher) {
            abort(403, 'Unauthorized');
        }

        $first_name = $teacher->first_name;
        $last_name  = $teacher->last_name;

        return [
            'teacher'           => $teacher,
            'teacher_name'      => trim($first_name . ' ' . $last_name),
            'teacher_position'  => $teacher->position ?: 'Teacher',
            'teacher_avatar'    => $teacher->profile_image ?? null,
            'sidebar_initials'  => strtoupper(substr($first_name, 0, 1) . substr($last_name, 0, 1)),
        ];
    }
}
