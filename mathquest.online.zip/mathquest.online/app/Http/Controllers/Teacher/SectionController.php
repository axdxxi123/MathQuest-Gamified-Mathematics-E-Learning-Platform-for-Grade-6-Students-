<?php

namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Section;

class SectionController extends BaseTeacherController
{
    public function index(Request $request)
    {
        $viewData = $this->teacherViewData();
        $teacher = $viewData['teacher'];

        // Get all active sections for this teacher
        $sections = Section::with('students')
            ->where('teacher_id', $teacher->teacher_id)
            ->where('archived', 0)
            ->orderBy('date_created', 'desc')
            ->get();

        // Check if we are viewing a specific section's students
        $section_id = $request->query('section_id'); // optional query param
        $students = collect();

        if ($section_id) {
            $section = $sections->where('section_id', $section_id)->first();
            if ($section) {
                $students = $section->students->where('archived', 0);
            }
        }

        // Learner categories (for filters)
        $learner_categories = ['Slow Learner', 'Average Learner', 'Fast Learner'];

        // Optional: calculate class average score across all students
        $all_scores = [];
        foreach ($sections as $sec) {
            foreach ($sec->students as $student) {
                foreach ($student->studentQuizzes as $sq) {
                    $total_points = $sq->quiz->questions->sum('points');
                    if ($total_points > 0) {
                        $all_scores[] = ($sq->score / $total_points) * 100;
                    }
                }
            }
        }
        $class_average_score = !empty($all_scores) ? number_format(array_sum($all_scores) / count($all_scores), 2) : 0;

        return view('teacher.sections.index', array_merge($viewData, [
            'sections' => $sections,
            'students' => $students,
            'section_id' => $section_id,
            'learner_categories' => $learner_categories,
            'class_average_score' => $class_average_score,
        ]));
    }

    public function store(Request $request)
    {
        $teacher = Auth::guard('teacher')->user();

        $request->validate([
            'section_name' => 'required|string|max:50',
            'school_year'  => 'required|string|max:9',
        ]);

        Section::create([
            'teacher_id'   => $teacher->teacher_id,
            'section_name' => $request->section_name,
            'school_year'  => $request->school_year,
        ]);

        return redirect()->route('teacher.sections.index')
            ->with('success', 'Section created successfully.');
    }

    public function destroy($id)
    {
        $teacher = Auth::guard('teacher')->user();

        $section = Section::where('teacher_id', $teacher->teacher_id)
            ->where('section_id', $id)
            ->firstOrFail();

        $section->update(['archived' => 1]);

        return redirect()->route('teacher.sections.index')
            ->with('success', 'Section archived successfully.');
    }

    public function update(Request $request, $id)
{
    $teacher = Auth::guard('teacher')->user();

    // Validate input
    $request->validate([
        'section_name' => 'required|string|max:50',
        'school_year'  => 'required|string|max:9',
    ]);

    // Find the section for this teacher
    $section = Section::where('teacher_id', $teacher->teacher_id)
        ->where('section_id', $id)
        ->firstOrFail();

    // Update section
    $section->update([
        'section_name' => $request->section_name,
        'school_year'  => $request->school_year,
    ]);

    return redirect()->route('teacher.sections.index')
        ->with('success', 'Section updated successfully.');
}

}
