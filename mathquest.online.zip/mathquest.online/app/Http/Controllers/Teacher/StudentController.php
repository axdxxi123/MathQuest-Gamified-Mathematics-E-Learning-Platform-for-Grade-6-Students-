<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Student;
use App\Models\Section;

class StudentController extends BaseTeacherController
{
    // List of students (optional, mostly handled in SectionController)
    public function index(Request $request)
    {
        $viewData = $this->teacherViewData();
        $teacher = $viewData['teacher'];

        $sectionId = $request->query('section_id');
        $students = $teacher->students()->where('archived', 0)
            ->when($sectionId, fn($q) => $q->where('section_id', $sectionId))
            ->get();

        $sections = $teacher->sections()->where('archived', 0)->get();
        $learner_categories = ['Slow Learner', 'Average Learner', 'Fast Learner'];

        return view('teacher.sections.index', array_merge($viewData, [
            'students' => $students,
            'sections' => $sections,
            'learner_categories' => $learner_categories,
            'section_id' => $sectionId,
        ]));
    }

    // Store new student
    public function store(Request $request)
    {
        $request->validate([
            'first_name'       => 'required|string|max:50',
            'middle_name'      => 'nullable|string|max:50',
            'last_name'        => 'required|string|max:50',
            'lrn'              => 'required|string|max:12|unique:students,lrn',
            'section_id'       => 'required|exists:sections,section_id',
            'learner_category' => 'required|in:Slow Learner,Average Learner,Fast Learner',
        ]);

        // Generate a random 6-character alphanumeric passcode
        $passcode = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 6);

        Student::create([
            'first_name'       => $request->first_name,
            'middle_name'      => $request->middle_name,
            'last_name'        => $request->last_name,
            'lrn'              => $request->lrn,
            'section_id'       => $request->section_id,
            'learner_category' => $request->learner_category,
            'passcode'         => $passcode,
        ]);

        return redirect()->route('teacher.sections.index', ['section_id' => $request->section_id])
            ->with('success', 'Student added successfully.');
    }


    // Update student
    public function update(Request $request, $id)
    {
        $teacher = Auth::guard('teacher')->user();
        $student = Student::where('teacher_id', $teacher->teacher_id)
            ->where('student_id', $id)
            ->firstOrFail();

        $request->validate([
            'first_name' => 'required|string|max:50',
            'middle_name' => 'nullable|string|max:50',
            'last_name'  => 'required|string|max:50',
            'lrn'        => 'required|string|max:12|unique:students,lrn,' . $student->student_id . ',student_id',
            'section_id' => 'nullable|exists:sections,section_id',
            'learner_category' => 'required|in:Slow Learner,Average Learner,Fast Learner',
        ]);

        $student->update([
            'first_name' => $request->first_name,
            'middle_name' => $request->middle_name,
            'last_name'  => $request->last_name,
            'lrn'        => $request->lrn,
            'section_id' => $request->section_id,
            'learner_category' => $request->learner_category,
        ]);

        return redirect()->route('teacher.sections.index', [
            'action' => 'students',
            'section_id' => $request->section_id
        ])->with('success', 'Student updated successfully.');
    }

    // Archive student
    public function destroy($id)
    {
        $teacher = Auth::guard('teacher')->user();
        $student = Student::where('teacher_id', $teacher->teacher_id)
            ->where('student_id', $id)
            ->firstOrFail();

        $student->update(['archived' => 1]);

        return redirect()->back()->with('success', 'Student archived successfully.');
    }

    // Optional: reset passcode
    public function resetPasscode($id)
    {
        $teacher = Auth::guard('teacher')->user();
        $student = Student::where('teacher_id', $teacher->teacher_id)
            ->where('student_id', $id)
            ->firstOrFail();

        $student->update(['passcode' => rand(100000, 999999)]);

        return redirect()->back()->with('success', 'Student passcode reset successfully.');
    }
}
