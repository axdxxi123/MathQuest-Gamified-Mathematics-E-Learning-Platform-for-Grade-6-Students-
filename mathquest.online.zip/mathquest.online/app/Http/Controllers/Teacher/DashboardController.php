<?php

namespace App\Http\Controllers\Teacher;

use App\Models\Student;
use App\Models\LearningMaterial;
use App\Models\Quiz;
use Carbon\Carbon;

class DashboardController extends BaseTeacherController
{
    public function index()
    {
        // Centralized teacher credentials
        $viewData = $this->teacherViewData();
        $teacher  = $viewData['teacher'];

        // Sections
        $sections = $teacher->sections()
            ->where('archived', 0)
            ->get();

        $sectionIds     = $sections->pluck('section_id');
        $sections_list  = $sections->pluck('section_name')->toArray();

        // Counts
        $students_count = Student::whereIn('section_id', $sectionIds)->count();
        $materials_count = LearningMaterial::where('teacher_id', $teacher->teacher_id)->count();
        $quizzes_count   = Quiz::where('teacher_id', $teacher->teacher_id)->count();

        /**
         * CLASS AVERAGE SCORE
         * Safe, schema-accurate, no SQL group misuse
         */
        $scores = [];

        foreach ($sections as $section) {
            foreach ($section->students as $student) {
                foreach ($student->studentQuizzes as $sq) {
                    if ($sq->score === null || !$sq->quiz) {
                        continue;
                    }

                    $totalPoints = $sq->quiz->questions->sum('points');
                    if ($totalPoints > 0) {
                        $scores[] = ($sq->score / $totalPoints) * 100;
                    }
                }
            }
        }

        $class_average_score = empty($scores)
            ? '0.00'
            : number_format(array_sum($scores) / count($scores), 2);

        // Recent activity feed
        $recent_activities = $this->getRecentActivities($teacher);

        return view(
            'teacher.dashboard.index',
            array_merge($viewData, [
                'sections'            => $sections,
                'sections_list'       => $sections_list,
                'students_count'      => $students_count,
                'materials_count'     => $materials_count,
                'quizzes_count'       => $quizzes_count,
                'class_average_score' => $class_average_score,
                'recent_activities'   => $recent_activities,
            ])
        );
    }

    private function getRecentActivities($teacher)
    {
        $activities = [];
        $now = Carbon::now();

        // 1. New sections
        $teacher->sections()->latest('date_created')->take(5)->get()->each(function ($s) use (&$activities, $now) {
            $activities[] = [
                'icon' => 'fa-chalkboard',
                'title' => 'New Section Created',
                'desc' => $s->section_name . ' (' . $s->school_year . ')',
                'time' => $s->date_created->diffForHumans($now),
                'timestamp' => $s->date_created
            ];
        });

        // 2. New students
        foreach ($teacher->sections as $section) {
            $section->students()->latest('date_created')->take(5)->get()->each(function ($st) use (&$activities, $now, $section) {
                $activities[] = [
                    'icon' => 'fa-user-plus',
                    'title' => 'New Student Added',
                    'desc' => $st->first_name . ' ' . $st->last_name . ' added to ' . $section->section_name,
                    'time' => $st->date_created->diffForHumans($now),
                    'timestamp' => $st->date_created
                ];
            });
        }

        // 3. New materials
        $teacher->learningMaterials()->latest('uploaded_at')->take(5)->get()->each(function ($lm) use (&$activities, $now) {
            $activities[] = [
                'icon' => 'fa-upload',
                'title' => 'New Material Uploaded',
                'desc' => $lm->title . ' (' . $lm->type . ')',
                'time' => $lm->uploaded_at->diffForHumans($now),
                'timestamp' => $lm->uploaded_at
            ];
        });

        // 4. New quizzes
        $teacher->quizzes()->latest('date_created')->take(5)->get()->each(function ($q) use (&$activities, $now) {
            $activities[] = [
                'icon' => 'fa-file-alt',
                'title' => 'New Quiz Created',
                'desc' => ucfirst($q->quiz_type) . ' quiz for week ' . $q->week,
                'time' => $q->date_created->diffForHumans($now),
                'timestamp' => $q->date_created
            ];
        });

        // 5. Student quizzes taken
        $teacher->sections->each(function ($section) use (&$activities, $now) {
            $section->students->each(function ($student) use (&$activities, $now) {
                $student->studentQuizzes()->latest('date_taken')->take(5)->get()->each(function ($sq) use (&$activities, $student, $now) {
                    $activities[] = [
                        'icon' => 'fa-check',
                        'title' => 'Quiz Taken',
                        'desc' => $student->first_name . ' ' . $student->last_name . ' scored ' . $sq->score . '% in week ' . $sq->quiz->week,
                        'time' => $sq->date_taken->diffForHumans($now),
                        'timestamp' => $sq->date_taken
                    ];
                });
            });
        });

        // Sort by timestamp descending and limit 10
        $activities = collect($activities)->sortByDesc('timestamp')->take(10)->values()->all();

        if (empty($activities)) {
            $activities[] = [
                'icon' => 'fa-info-circle',
                'title' => 'No recent activity',
                'desc' => '',
                'time' => ''
            ];
        }

        return $activities;
    }
}
