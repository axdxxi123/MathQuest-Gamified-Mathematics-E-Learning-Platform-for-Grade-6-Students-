<?php
namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Teacher;

class AuthController extends Controller
{
    // Show login page
    public function showLoginForm()
    {
        return view('teacher.auth.login');
    }

    // Login
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string|min:6',
        ]);

        $teacher = Teacher::where('email', $request->email)->first();

        if ($teacher && Hash::check($request->password, $teacher->password_hash)) {
            Auth::guard('teacher')->login($teacher, false);
            $request->session()->regenerate();
            return redirect()->route('teacher.dashboard.index');
        }

        return back()->with('error', 'Invalid email or password.')->withInput();
    }

    // Show signup page
    public function showSignupForm()
    {
        return view('teacher.auth.signup');
    }

    // Signup
    public function signup(Request $request)
    {
        $request->validate([
            'firstname' => 'required|string|max:50',
            'middlename' => 'nullable|string|max:50',
            'lastname' => 'required|string|max:50',
            'position' => 'required|in:Teacher I,Teacher II,Teacher III,Teacher IV,Teacher V,Teacher VI,Master Teacher I,Master Teacher II,Master Teacher III,Master Teacher IV,Master Teacher V,Master Teacher VI',
            'email' => 'required|email|unique:teachers,email',
            'password' => 'required|confirmed|min:6',
            'terms' => 'accepted',
        ]);

        $teacher = Teacher::create([
            'first_name' => $request->firstname,
            'middle_name' => $request->middlename,
            'last_name' => $request->lastname,
            'position' => $request->position,
            'email' => $request->email,
            'password_hash' => Hash::make($request->password),
        ]);

        Auth::guard('teacher')->login($teacher);

        return redirect()->route('teacher.dashboard.index');
    }

    // Logout
    public function logout(Request $request)
    {
        Auth::guard('teacher')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('teacher.login')->with('success', 'Logged out successfully.');
    }
}
