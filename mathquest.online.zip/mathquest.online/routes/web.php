<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Teacher\AuthController;
use App\Http\Controllers\Teacher\DashboardController;
use App\Http\Controllers\Teacher\SectionController;
use App\Http\Controllers\Teacher\StudentController;
use App\Http\Controllers\Teacher\StudentArchiveController;
use App\Http\Controllers\Teacher\QuizController;
use App\Http\Controllers\Teacher\QuestionController;
use App\Http\Controllers\Teacher\LearningMaterialController;
use App\Http\Controllers\Teacher\ReportsController;
use App\Http\Controllers\Teacher\SettingsController;

Route::get('/', function () {
    return view('public.index');
})->name('index');

Route::prefix('teacher')->name('teacher.')->group(function () {

    // Authentication
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/signup', [AuthController::class, 'showSignupForm'])->name('signup');
    Route::post('/signup', [AuthController::class, 'signup']);
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Protected routes
    Route::middleware(['auth:teacher'])->group(function () {

        // Dashboard
        Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');

        // Sections
        Route::get('/sections', [SectionController::class, 'index'])->name('sections.index');
        Route::post('/sections', [SectionController::class, 'store'])->name('sections.store');
        Route::post('/sections/{section}/update', [SectionController::class, 'update'])->name('sections.update');
        Route::delete('/sections/{section}', [SectionController::class, 'destroy'])->name('sections.destroy');
        Route::post('/sections/{section}/archive', [SectionController::class, 'archive'])->name('sections.archive');

        // Students
        Route::resource('students', StudentController::class);

        // Student archives
        Route::get('/student-archives', [StudentArchiveController::class, 'index'])->name('student_archives.index');

        // Quizzes, Questions, Modules, Reports, Settings
        Route::resource('quizzes', QuizController::class);
        Route::resource('questions', QuestionController::class);
        Route::resource('modules', LearningMaterialController::class);
        Route::resource('reports', ReportsController::class);
        Route::resource('settings', SettingsController::class);
    });
});
